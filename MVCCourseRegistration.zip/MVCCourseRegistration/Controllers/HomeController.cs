﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MVCCourseRegistration.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace MVCCourseRegistration.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Instructors()
        {
            InstructorViewModel avm = new InstructorViewModel();

            List<DTO.Instructors> Instructors = new List<DTO.Instructors>()
            {
                new DTO.Instructors{ InstructorId = 1, FirstName = "Spong-Bob", LastName = "Square-Pants", EmailAddress = "B.Square-Pants@underthesea.ca", Course= "Math" },
                new DTO.Instructors{ InstructorId = 2, FirstName = "Snow", LastName = "White", EmailAddress = "S-White@underthesea.ca", Course= "English" },
                new DTO.Instructors{ InstructorId = 3, FirstName = "Red", LastName = "Riding-Hood", EmailAddress = "R-Hood@underthesea.ca", Course= "Science" },
                new DTO.Instructors{ InstructorId = 4, FirstName = "Patric", LastName = "Star-Fish", EmailAddress = "P-Fish@underthesea.ca", Course= "Physical Education" },
                new DTO.Instructors{ InstructorId = 5, FirstName = "Squid", LastName = "Word", EmailAddress = "S-Word@underthesea.ca", Course= "History" },
                new DTO.Instructors{ InstructorId = 6, FirstName = "Sally", LastName = "Pants", EmailAddress = "S-Pants@underthesea.ca", Course= "Computer Science" },
            };
            avm.Instructors = Instructors;

            return View(avm);
        }
        public IActionResult Student()
        {
            StudentViewModel avm = new StudentViewModel();

            List<DTO.Student> Students = new List<DTO.Student>()
            {
                new DTO.Student{ StudentId = 111, FirstName = "Katie", LastName = "Under-Wood", EmailAddress = "Katie-UW@underthesea.ca", PhoneNumber = "123-456-78901" },
                new DTO.Student{ StudentId = 112, FirstName = "Bob", LastName = "Dillion", EmailAddress = "B-Dillion@underthesea.ca", PhoneNumber = "123-876-54321" },
                new DTO.Student{ StudentId = 113, FirstName = "Katie", LastName = "Perry", EmailAddress = "Katie-P@underthesea.ca", PhoneNumber = "123-987-1234" },
                new DTO.Student{ StudentId = 114, FirstName = "Ozzy", LastName = "Ozborn", EmailAddress = "O-Ozborn@underthesea.ca", PhoneNumber = "123-665-3475" },
                new DTO.Student{ StudentId = 115, FirstName = "Tom", LastName = "Cruise", EmailAddress = "T-Cruise@underthesea.ca", PhoneNumber = "123-569-8765" },
                new DTO.Student{ StudentId = 116, FirstName = "Emma", LastName = "Stone", EmailAddress = "E-Stone@underthesea.ca", PhoneNumber = "123-456-7778"  },
                new DTO.Student{ StudentId = 116, FirstName = "Natalie", LastName = "Portman", EmailAddress = "N-Portman@underthesea.ca", PhoneNumber = "123-456-4378" },
                new DTO.Student{ StudentId = 116, FirstName = "Tom", LastName = "Hanks", EmailAddress = "T-Hanks@underthesea.ca", PhoneNumber = "123-456-5278" },
                new DTO.Student{ StudentId = 116, FirstName = "Johnny", LastName = "Depp", EmailAddress = "J-Depp@underthesea.ca", PhoneNumber = "123-436-8578" },
                new DTO.Student{ StudentId = 116, FirstName = "Brad", LastName = "Pitt", EmailAddress = "B-Pitt@underthesea.ca", PhoneNumber = "123-956-2378" },
                new DTO.Student{ StudentId = 116, FirstName = "Tinna", LastName = "Turner", EmailAddress = "T-Turner@underthesea.ca", PhoneNumber = "123-476-7988" },
                new DTO.Student{ StudentId = 116, FirstName = "Julia", LastName = "Roberts", EmailAddress = "J-Roberts@underthesea.ca", PhoneNumber = "123-856-7732" },
                new DTO.Student{ StudentId = 116, FirstName = "Will", LastName = "Smith", EmailAddress = "W-Smith@underthesea.ca", PhoneNumber = "123-746-9388" },
                new DTO.Student{ StudentId = 116, FirstName = "Robert", LastName = "Downey, Jr.", EmailAddress = "R-Downey.Jr@underthesea.ca", PhoneNumber = "123-456-3448" },
                new DTO.Student{ StudentId = 116, FirstName = "Angelina", LastName = "Jolie", EmailAddress = "A-Jolie@underthesea.ca", PhoneNumber = "123-456-7778" },
            };
            avm.Students = Students;

            return View(avm);
        }
        public IActionResult Courses()
        {
            CourseViewModel avm = new CourseViewModel();

            List<DTO.Courses> Courses = new List<DTO.Courses>()
            {
                new DTO.Courses{ CourseId = 101, CourseNumber = 12345, CourseName = "Math", Description = "Learn to add numbers" },
                new DTO.Courses{ CourseId = 102, CourseNumber = 54321, CourseName = "English", Description = "Learn to read" },
                new DTO.Courses{ CourseId = 103, CourseNumber = 13579, CourseName = "Science", Description = "Learn to be a mad scientist" },
                new DTO.Courses{ CourseId = 104, CourseNumber = 98765, CourseName = "Physical Education", Description = "Get some excersise" },
                new DTO.Courses{ CourseId = 105, CourseNumber = 43210, CourseName = "Computer Science", Description = "Learn computers" },
                new DTO.Courses{ CourseId = 106, CourseNumber = 24680, CourseName = "History", Description = "Learn the past"  },
            };
            avm.Courses = Courses;

            return View(avm);

        }
        public IActionResult Admission()
        {
            AdmissionViewModel avm = new AdmissionViewModel();

            List<DTO.Admission> Admissions = new List<DTO.Admission>()
            {
                new DTO.Admission{ CourseId = 101, CourseNumber = 12345, CourseName = "Math", CourseCost = 1.23 },
                new DTO.Admission{ CourseId = 102, CourseNumber = 54321, CourseName = "English", CourseCost = 1.23 },
                new DTO.Admission{ CourseId = 103, CourseNumber = 13579, CourseName = "Science", CourseCost = 1.23 },
                new DTO.Admission{ CourseId = 104, CourseNumber = 98765, CourseName = "Physical", CourseCost = 1.23 },
                new DTO.Admission{ CourseId = 105, CourseNumber = 43210, CourseName = "Computer Science", CourseCost = 1.23 },
                new DTO.Admission{ CourseId = 106, CourseNumber = 24680, CourseName = "History", CourseCost = 1.23  },
            };
            avm.Admissions = Admissions;

            return View(avm);
        }
        public IActionResult Registration()
        {
            return View();
        }
        public IActionResult Student_Services()
        {
            return View();
        }
        public IActionResult Privacy()
        {
            return View();
        }
        public IActionResult GetStudentsbyCourseview()
        {
            return View();
        }
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
