﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVCCourseRegistration.DTO
{
    public class Courses
    {
        public int CourseId { get; set; }
        public int CourseNumber { get; set; }
        public string CourseName { get; set; }
        public string Description { get; set; }

    }
}
