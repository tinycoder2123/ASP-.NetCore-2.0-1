﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVCCourseRegistration.Models
{
    public class AdmissionViewModel
    {
        public List<DTO.Admission> Admissions { get; set; }
    }
}
