﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVCCourseRegistration.Models
{
    public class CourseViewModel
    {
        public List<DTO.Courses> Courses { get; set; }
    }
}
